#!/bin/bash
##############################
# NETCAT Killer
##############################
# ChangeLog:
# 2013-05-02 Initial Creation
##############################

# Binaries
KILLALL="/usr/bin/killall"

# Variables
BACKUP_USER="ncbackup"
TAR_COMMAND="tar -c /opt/backup/test"
TAR_PID_FILE="/opt/ncscripts/backup/backup_tar.pid"


TAR_PID=`/bin/ps -u $BACKUP_USER -opid,command | grep "$TAR_COMMAND" | awk -F' ' '{print $1}'`

echo $TAR_PID | cut -d' ' -f1 > /opt/ncscripts/backup/backup_tar.pid

PID=`cat $TAR_PID_FILE`
while true
do
	if  ps -p $PID >&- ; then
  		sleep 300
	else
		$KILLALL netcat
		break
	fi
done

echo "Tar PID: $TAR_PID killed and all netcat killed"

