#!/bin/bash
##############################
# NETCAT backup file transfer
##############################
# ChangeLog:
# 2013-05-02 Initial Creation
##############################

# Binaries
SSH="/usr/bin/ssh"
DATE="/bin/date"
NETCAT="/usr/local/bin/netcat"

SSH_USER=bckuser
BACKUP_SERVER=192.168.0.10
BACKUP_DIR="/data/backup"
HOSTNAME="srv-wandoujia-db8"
BACKUP_FOLDER="$BACKUP_DIR/$HOSTNAME"
RECEIVER_PORT=19000

BACKUP_ID_RSA="/opt/ncscripts/backup/key/id_rsa"
DATE_FORMATED=`$DATE "+%y%m%d_%H%M%S"`
PREFIX_BACKUP="$DATE_FORMATED"_"$HOSTNAME"
FULL_BACKUP="$PREFIX_BACKUP.tar"

echo "RECEIVING NOW!"
EXEC_REMOTE_SSH="$SSH -i $BACKUP_ID_RSA $SSH_USER@$BACKUP_SERVER"
$EXEC_REMOTE_SSH "mkdir -p $BACKUP_FOLDER"
$EXEC_REMOTE_SSH "$NETCAT -l -p $RECEIVER_PORT > $BACKUP_FOLDER/$FULL_BACKUP"
echo "RECEIVE COMPLETE!"

$EXEC_REMOTE_SSH "ls -lahp $BACKUP_FOLDER/$FULL_BACKUP"

