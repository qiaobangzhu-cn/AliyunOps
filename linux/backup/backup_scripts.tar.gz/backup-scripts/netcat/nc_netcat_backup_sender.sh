#!/bin/bash
##############################
# NETCAT backup file transfer
##############################
# ChangeLog:
# 2013-05-02 Initial Creation
##############################

# Binaries
TAR="/bin/tar"
NETCAT="/usr/local/bin/netcat"

RECEIVER_HOST=192.168.0.10
RECEIVER_PORT=19000
HOSTNAME="srv-wandoujia-db8"


SOURCE_FILE="/opt/backup/test"

echo "SENDING NOW!"
$TAR -c "$SOURCE_FILE" | $NETCAT $RECEIVER_HOST $RECEIVER_PORT
if [ $? -eq 0 ]; then
   echo "SEND COMPLETE!" |mail -s "-- OK [$HOSTNAME] backup report -" ncbackup_report@chinanetcloud.com
else
   echo "SEND ERROR!" |mail -s "FAILED [$HOSTNAME] backup report -" ncbackup_report@chinanetcloud.com
fi

