#!/bin/bash
################################################
# POSTSQL DB backup
#
# Contact: Kylix.tan@chinanetcloud.com
# Version: 0.1
# Changes:
#   2010-06-12: Initial creation
#   2011-08-30: AS - Bacula-ize

################################################
#
# OUTPUT:
#  - 1 backup archive tar.gz -- Naming Format: prefix_XXXXX.tar.gz
#  - STDOUT -- to be appened to mail notice
#  - STDERR -- to be appened to error log for mail notice
################################################
# TODO:
#  - backup archivelog individually if database running in archive mode
#
SCRIPT_PREFIX="pgdump-bacula"

# Define default extra files to include in the archive
SOURCE_FOLDER=""

################################################
# BINARY Details
################################################
PSQLDUMP="/opt/postgresql/bin/pg_dump"
PSQL="/opt/postgresql/bin/psql"

#
## Check binaries
# PSQLDUMP

if [ ! -x "$PSQLDUMP" ]; then
  echo "$PSQLDUMP -- command not found" >&2
  exit 2
fi 

#
## Check binaries
#PSQL

if [ ! -x "$PSQL" ]; then
  echo "$PSQL -- command not found" >&2
  exit 2
fi 

##################################################
# Manage parameters
##################################################
#

## Manage parameters
DATE_FORMATED=`date +%y%m%d_%H%M%S`
HOSTNAME=`hostname`
DESTINATION_FOLDER=/opt/backup
PREFIX="$DATE_FORMATED"_"$HOSTNAME"

#
## Check for valid destination folder
if [ ! -d "$DESTINATION_FOLDER" ]; then
  echo "$DESTINATION_FOLDER : no such file or directory" >&2
  exit 2
fi


#
## File name definition
BACKUP_FOLDER="$DESTINATION_FOLDER"/"$SCRIPT_PREFIX"
BACKUP_FILE="$BACKUP_FOLDER"/"$PREFIX"_"$SCRIPT_PREFIX"

#
## check for custom backup folder
if [ ! -d "$BACKUP_FOLDER" ]; then
  mkdir -p "$BACKUP_FOLDER"
  if [ $? -ne 0 ]; then echo " can't create directory $DESTINATION_FOLDER: Permission denied" ; exit 2 ; fi
fi

#
## Check for writable destination
if [ ! -w "$BACKUP_FOLDER" ]; then
  echo "can't acess $BACKUP_FOLDER: Permission denied" >&2
  exit 2
fi

## Delete previous backup
echo "---- Deleting old backup ---- "
rm -rf $BACKUP_FOLDER/*
  
#########################################
# DB backup
#########################################
#
## backup Database
#echo "Backing up Database : $DB_NAME"
#"$PSQLDUMP" --defaults-extra-file="$MYDUMP_PSQL_CREDS"  --add-locks --extended-insert --lock-tables --all-databases > "$BACKUP_FILE"
#echo "Backup Done."; echo
for DB_NAME in `$PSQL -U ncbackupdb postgres -c "select datname from pg_database;"  -t | grep -v ^$`;
do
  if [ ! "$DB_NAME" = "template0" ] ; then
      echo "Backing up Database : $DB_NAME"
      "$PSQLDUMP" -U ncbackupdb $DB_NAME > "$BACKUP_FILE"_"$DB_NAME".sql
      echo "Backup Done."; echo
  fi
done


#
## compress Database and return required format tar.gz
cd "$BACKUP_FOLDER"
echo "Compress file"
#FILE=`basename "$BACKUP_FILE"`
FILE=*.sql
tar czf "$BACKUP_FILE".sql.tar.gz $FILE 
if [ $? -ne 0 ]; then
   echo "Create $BACKUP_FILE.sql.tar.gz failed" >&2
   exit 2
fi
rm -f $FILE
echo "Compress Done."; echo


#
## display final archive details
echo "List archive"
ls -la "$BACKUP_FOLDER"
echo "List Details Done."