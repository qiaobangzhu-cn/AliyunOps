#!/bin/bash
################################################
# POSTSQL DB backup
#
# Contact: Kylix.tan@chinanetcloud.com
# Version: 0.1
# Changes:
#   2010-06-12: Initial creation

################################################
# Requirements from the Master script API
#
# INPUT:
#  - $1 -- root destination backup folder
#  - $2 -- archive PREFIX
#  - $3 -- backup config file
#
# OUTPUT:
#  - 1 backup archive tar.gz -- Naming Format: prefix_XXXXX.tar.gz
#  - STDOUT -- to be appened to mail notice
#  - STDERR -- to be appened to error log for mail notice
################################################
# TODO:
#  - backup archivelog individually if database running in archive mode
#

SCRIPT_PREFIX="pgdump"

# Define default extra files to include in the archive
SOURCE_FOLDER=""

################################################
# BINARY Details
################################################
PSQLDUMP="/usr/bin/pg_dump"
PSQL="/usr/bin/psql"

#
## Check binaries
# PSQLDUMP

if [ ! -x "$PSQLDUMP" ]; then
  echo "$PSQLDUMP -- command not found" >&2
  exit 2
fi 

#
## Check binaries
#PSQL

if [ ! -x "$PSQL" ]; then
  echo "$PSQL -- command not found" >&2
  exit 2
fi 

##################################################
# Manage parameters
##################################################
#

## check parameter
if [ $# -ne 3 ]; then
  echo "Not enough parameter setup" >&2
  exit 2
fi

## Save parameters
DESTINATION_FOLDER="$1"
PREFIX="$2"
BACKUP_CONFIG_FILE="$3"

#
## Check for valid destination folder
if [ ! -d "$DESTINATION_FOLDER" ]; then
  echo "$DESTINATION_FOLDER : no such file or directory" >&2
  exit 2
fi



#
## Check for valid configuration file
if [ -f "$BACKUP_CONFIG_FILE" -a -r "$BACKUP_CONFIG_FILE" ]; then 
  source "$BACKUP_CONFIG_FILE"
else
  echo "can't access $BACKUP_CONFIG_FILE: Permission denied" >&2
  exit 2
fi

#
## File name definition
BACKUP_FOLDER="$DESTINATION_FOLDER"/"$SCRIPT_PREFIX"
BACKUP_FILE="$BACKUP_FOLDER"/"$PREFIX"_"$SCRIPT_PREFIX"

#
## check for custom backup folder
if [ ! -d "$BACKUP_FOLDER" ]; then
  mkdir -p "$BACKUP_FOLDER"
  if [ $? -ne 0 ]; then echo " can't create directory $DESTINATION_FOLDER: Permission denied" ; exit 2 ; fi
fi

#
## Check for writable destination
if [ ! -w "$BACKUP_FOLDER" ]; then
  echo "can't acess $BACKUP_FOLDER: Permission denied" >&2
  exit 2
fi
  


#
## check if the mysql Credentials are correct
#if [ ! -s "$MYDUMP_PSQL_CREDS" ]; then
#	echo "Invalid MySQL credential files: $MYDUMP_PSQL_CREDS" >&2
#	exit 1
#fi


#########################################
# DB backup
#########################################
#
## backup Database
#echo "Backing up Database : $DB_NAME"
#"$PSQLDUMP" --defaults-extra-file="$MYDUMP_PSQL_CREDS"  --add-locks --extended-insert --lock-tables --all-databases > "$BACKUP_FILE"
#echo "Backup Done."; echo
for DB_NAME in `$PSQL -U ncbackupdb postgres -c "select datname from pg_database;"  -t | grep -v ^$`;
do
  if [ ! "$DB_NAME" = "template0" ] ; then
      echo "Backing up Database : $DB_NAME"
      "$PSQLDUMP" -U ncbackupdb $DB_NAME > "$BACKUP_FILE"_"$DB_NAME".sql
      echo "Backup Done."; echo
  fi
done


#
## compress Database and return required format tar.gz
cd "$BACKUP_FOLDER"
echo "Compress file"
#FILE=`basename "$BACKUP_FILE"`
FILE=*.sql
tar czf "$BACKUP_FILE".sql.tar.gz $FILE 
if [ $? -ne 0 ]; then
   echo "Create $BACKUP_FILE.sql.tar.gz failed" >&2
   exit 2
fi
rm -f $FILE
echo "Compress Done."; echo


#
## display final archive details
echo "List archive"
ls -la "$BACKUP_FOLDER"
echo "List Details Done."

