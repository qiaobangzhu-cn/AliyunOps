#!/bin/bash
################################################
# MySQL DB backup
#
# Contact: vincent.viallet@gmail.com
# Version: 0.1
# Changes:
#   2009-03-10: Initial creation
#   2009-06-05 DL
#       2010-01-21      VV      add config file
#       2010-02-04      CH      add for loop to do the backup database by database
#       2010-03-30      JS      add check binaries for mysql command and Mysql Log rotate 
#       2010-09-06      DL      add Innodb option for the databases which only has Innodb tables
#       2011-01-28  CH  Move the location of "flush logs" etc
#                       Merge the parameter of mysqldump and creds file
#                       Adjust the option for mysqldump during the backup
#       20011-02-15     AL       Bacula-ize
################################################
# Requirements from the Master script API
#
# INPUT:
#  - $1 -- root destination backup folder
#  - $2 -- archive PREFIX
#  - $3 -- backup config file
#
# OUTPUT:
#  - 1 backup archive tar.gz -- Naming Format: prefix_XXXXX.tar.gz
#  - STDOUT -- to be appened to mail notice
#  - STDERR -- to be appened to error log for mail notice
################################################
SCRIPT_PREFIX="mydump-bacula"
MYDUMP_MYSQL_CREDS=/opt/ncscripts/backup-bacula/mysql_backup.creds

################################################
# BINARY Details
################################################
MYSQLDUMP="/usr/bin/mysqldump"
MYSQL="/usr/bin/mysql"

# MYSQLDUMP
if [ ! -f "$MYSQLDUMP" ]; then
  echo "ERROR: MYSQLDUMP: $MYSQLDUMP -- binary not found" >&2
  exit 2
fi
if [ ! -x "$MYSQLDUMP" ]; then
  echo "ERROR: MYSQLDUMP: $MYSQLDUMP -- binary not executable" >&2
  exit 2
fi

#MYSQL
if [ ! -f "$MYSQL" ]; then
  echo "ERROR: MYSQL: $MYSQL -- binary not found" >&2
  exit 2
fi
if [ ! -x "$MYSQL" ]; then
  echo "MYSQL: $MYSQL -- binary not executable" >&2
  exit 2
fi
##################################################
# Manage parameters
##################################################
DATE_FORMATED=`date +%y%m%d_%H%M%S`
HOSTNAME=`hostname`
DESTINATION_FOLDER=/opt/backup/
PREFIX="$DATE_FORMATED"_"$HOSTNAME"

## Check for valid destination folder
if [ ! -d "$DESTINATION_FOLDER" ]; then
  echo "ERROR: $DESTINATION_FOLDER is not a valid folder" >&2
  exit 2
fi

## Check parameters
if [ -z "$DESTINATION_FOLDER" ]; then
  echo "ERROR: Missing destination folder" >&2
  exit 2
fi

if [ -z "$PREFIX" ]; then
  echo "ERROR: Missing master backup prefix" >&2
  exit 2
fi

## Check for valid FULL PATH
if [ ${DESTINATION_FOLDER:0:1} != '/' ]; then
  echo "ERROR: Need FULL PATH for destination backup folder" >&2
  exit 2
fi

## Parameter for binary and creds file
MYSQLDUMP_AND_CREDS="$MYSQLDUMP --defaults-extra-file=$MYDUMP_MYSQL_CREDS"
MYSQL_AND_CREDS="$MYSQL --defaults-extra-file=$MYDUMP_MYSQL_CREDS"
#
## File name definition
BACKUP_FOLDER="$DESTINATION_FOLDER"/"$SCRIPT_PREFIX"
BACKUP_FILE="$BACKUP_FOLDER"/"$PREFIX"_"$SCRIPT_PREFIX".sql

## check for custom backup folder
if [ ! -d "$BACKUP_FOLDER" ]; then
  mkdir -p "$BACKUP_FOLDER"
  if [ $? -ne 0 ]; then echo "ERROR: $DESTINATION_FOLDER folder is not writable, check permissions" ; exit 2 ; fi
fi

## Delete previous backup
echo "---- Deleting old backup ---- "
rm -rf $BACKUP_FOLDER/*

## check if the mysql Credentials are correct
if [ ! -s "$MYDUMP_MYSQL_CREDS" ]; then
  echo "ERROR: Invalid MySQL credential files: $MYDUMP_MYSQL_CREDS" >&2
  exit 1
fi

########################################
# Log Rotate 
#######################################
#Define SQL
SQL="
\! echo '---- Flushing logs ----'
flush logs;
\! echo '---- Show master status ----' 
SHOW MASTER STATUS;
\! echo '---- Show slave status ----'
SHOW SLAVE STATUS \G
"
$MYSQL_AND_CREDS -e "$SQL" >/dev/null


#########################################
# DB backup
#########################################
#
## backup Database
for DB_NAME in $($MYSQL_AND_CREDS -e "show databases" | sed '/Database/d' | grep -v "information_schema");
do
  echo "---- Backing up Database : $DB_NAME ---- "
  if echo "SHOW TABLE STATUS FROM $DB_NAME;" | $MYSQL_AND_CREDS --skip-column-name | grep -iv "innodb" >/dev/null;then
    echo "---- $DB_NAME has MYISAM TABLES , using DUMP backup method ---- "
    $MYSQLDUMP_AND_CREDS --opt --routines --triggers --events --flush-privileges --skip-add-drop-table --master-data=2 --dump-date --databases $DB_NAME | gzip > "$BACKUP_FOLDER"/"$PREFIX"_"$SCRIPT_PREFIX"_"$DB_NAME".sql.gz
  else
    echo "---- $DB_NAME has all InnoDB tables , using InnoDB backup method ---- "
    $MYSQLDUMP_AND_CREDS --opt --routines --triggers --events --flush-privileges --skip-add-drop-table --master-data=2 --single-transaction  --skip-add-locks --dump-date --databases $DB_NAME | gzip > "$BACKUP_FOLDER"/"$PREFIX"_"$SCRIPT_PREFIX"_"$DB_NAME".sql.gz
  fi
  echo "---- Backup Done ---- ";
done

## check for FULL PATH only in SOURCE_FOLDER
for folder in ${SOURCE_FOLDER} ${MYDUMP_EXTRA_DATA}
do
  if [ ${folder:0:1} != '/' ]; then
    echo "ERROR: Need FULL PATH for source backup folders / files" >&2
    exit 2
  fi
done

## compress Database and return required format tar.gz
cd "$BACKUP_FOLDER"
echo "---- Compress file ---- "
FILE=*.sql.gz
tar czf "$BACKUP_FILE".tar.gz $FILE $SOURCE_FOLDER $MYDUMP_EXTRA_DATA --remove-files
echo "---- Compress Done ---- ";

ls -lh "$BACKUP_FOLDER"/*gz