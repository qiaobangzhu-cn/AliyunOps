################################################
# LVM Backup script - for Mongodb
#
################################################
# Contact: 
#       rexx.wu@chinanetcloud.com
#
# ChangeLog:
#       2011-09-14          Change mylvm for mysql.
################################################
################################################
# Requirements from the Master script API
#
# INPUT:
#  - $1 -- root destination backup folder
#  - $2 -- archive PREFIX
#  - $3 -- backup config file
#
# OUTPUT:
#  - 1 backup archive tar.gz -- Naming Format: prefix_XXXXX.tar.gz
#  - STDOUT -- to be appened to mail notice
#  - STDERR -- to be appened to error log for mail notice
################################################
###############
# Configurable Variables
###############
#MYLVM_MYSQL_CREDS=/opt/ncscripts/backup/key/mysql_backup.creds
MY_VG=domudbvg
MY_LV=mongodb
MY_LV_DATADIR=data
SNAP_SIZE=1024M
SNAP_MOUNT=/mnt/snapshot

SCRIPT_PREFIX="mylvm-bacula"
##################################################
# Manage parameters
##################################################
#
## Save parameters
DATE=`date +%y%m%d_%H%M%S`
DATE_FORMATED=`date +%y%m%d_%H%M%S`
HOSTNAME=`hostname`
DESTINATION_FOLDER=/opt/backup/
PREFIX="$DATE_FORMATED"_"$HOSTNAME"

## Check parameters
if [ -z "$DESTINATION_FOLDER" ]; then
echo "Error: Missing destination folder" >&2
exit 2
fi

if [ -z "$PREFIX" ]; then
echo "Error: Missing master backup prefix" >&2
exit 2
fi

## Check for valid destination folder
if [ ! -d "$DESTINATION_FOLDER" ]; then
echo "Error: $DESTINATION_FOLDER is not a valid folder" >&2
exit 2
fi

## File name definition
BACKUP_FOLDER="$DESTINATION_FOLDER"/"$SCRIPT_PREFIX"
BACKUP_FILE="$BACKUP_FOLDER"/"$PREFIX"_"$SCRIPT_PREFIX".tar.gz

## check for custom backup folder
if [ ! -d "$BACKUP_FOLDER" ]; then
mkdir -p "$BACKUP_FOLDER"
if [ $? -ne 0 ]; then echo "Error: $DESTINATION_FOLDER folder is not writable, check permissions" ; exit 2 ; fi
fi


#######################
# Binaries
#######################
LVCREATE="/usr/sbin/lvcreate"           # to create the snapshot
LVREMOVE="/usr/sbin/lvremove"           # to remove the snapshot
VGDISPLAY="/usr/sbin/vgdisplay"         # to check on the available disk space for the snapshot
LVDISPLAY="/usr/sbin/lvdisplay"         # to check on the available disk space for the snapshot
LVS="/usr/sbin/lvs"                     # to provide a list of detailed info for the VG and LV
MONGO="/usr/bin/mongo"                  # to perform required locks on the DBs

####################### 
# MySQL Details
#######################
#if [ ! -s "$MYLVM_MYSQL_CREDS" ]; then
#  echo "Error: Invalid MySQL credential files: $MYLVM_MYSQL_CREDS" >&2
#  exit 1
#fi
#EXEC_MYSQL="$MYSQL --defaults-extra-file=$MYLVM_MYSQL_CREDS"
EXEC_MONGO="$MONGO"

######################
# LVM Details
######################
# Define the snapshot details
SNAP_NAME=mongo_snap_$DATE
if [ ! -d "$SNAP_MOUNT" ]; then
mkdir -p $SNAP_MOUNT
if [ $? -ne 0 ]; then
echo "Error: Impossible to create snapshot mount point: $SNAP_MOUNT" >&2
exit 1
fi
fi

################################################
# Checks
################################################
# Check for binaries
binary_check() {
if [ -z "$1" ]; then
echo "Error: missing argument (binary_check())" >&2
exit 1
fi
if [ ! -e "$1" -o ! -x "$1" ]; then
echo "Error: '$1' is not a valid binary, please correct the binary definition (binary_check())" >&2
exit 1
fi
}
binary_check $LVCREATE
binary_check $LVREMOVE
binary_check $VGDISPLAY
binary_check $LVDISPLAY
binary_check $LVS
binary_check $MONGO

## check the variables are properly set
if [ -z "$MY_VG" ]; then
echo "Error: Missing volume groupe (VG) - please configure MY_VG" >&2
exit 1
fi
if [ -z "$MY_LV" ]; then
echo "Error: Missing logical volume (LV) - please configure MY_LV" >&2
exit 1
fi
if [ -z "$MY_LV_DATADIR" ]; then
echo "Error: Missing mongo datadir - please configure MY_LV_DATADIR" >&2
exit 1
fi
if [ -z "$SNAP_SIZE" ]; then
echo "Error: Snapshot size is NOT properly defined - please reconfigure SNAP_SIZE" >&2
exit 1
fi
if [ -z "$SNAP_MOUNT" ]; then
echo "Error: Snapshot mount point is NOT properly defined - please reconfigure SNAP_MOUNT" >&2
exit 1
fi

################
## Check LVM
################
# check if the variables exist in the system
# only 1 line output if not existing
VG_EXIST=`$VGDISPLAY $MY_VG | wc -l`
if [ ! $((VG_EXIST)) -gt 2 ]; then
echo "Error: $MY_VG is not a valid Volume Group" >&2
echo "Error: Select one of the following :" >&2
$VGDISPLAY -s >&2
exit 1
fi

# only 1 line output if not existing
LV_EXIST=`$LVDISPLAY /dev/$MY_VG/$MY_LV | wc -l`
if [ ! $((LV_EXIST)) -gt 2 ]; then
echo "Error: $MY_LV is not a valid Logical Volume in $MY_VG Volume Group" >&2
echo "Error: Select one of the following :" >&2
$LVS >&2
exit 1
fi

# We create the snapshot from within the mongo prompt in order to keep the table lock enabled
# by default the table lock either get released when the connection closed or when the unlock tables
# is provided
SQL_PRE="
use admin;
db.runCommand({fsync:1,lock:1});
db.currentOp();
"

SQL_END="
use admin;
db.\$cmd.sys.unlock.findOne();
sleep(1000);
db.currentOp();
"

SQL_SNAP_LOG=/tmp/sql_snap_$DATE.log

logger "$DATE - `basename $0` | Mongodb LVM Backup startup"
#
echo "---- Deleting old backup ---- "
rm -rf $BACKUP_FOLDER/*

#
## perform lock and snapshot creation
echo "---- Starting MONGO flush with read lock and LVM snapshot ---- "

# Export environment variable to suppress warning during lvm snapshot 
export LVM_SUPPRESS_FD_WARNINGS
date_lock_start=`date "+%s"`

# we use "tee" to save the output in a file and still display the messages in stdout
echo "$SQL_PRE" | $EXEC_MONGO | tee $SQL_SNAP_LOG
$LVCREATE --snapshot --size=$SNAP_SIZE --name $SNAP_NAME /dev/$MY_VG/$MY_LV
echo "$SQL_END" | $EXEC_MONGO | tee $SQL_SNAP_LOG
date_lock_end=`date "+%s"`
date_lock_length=$((date_lock_end-date_lock_start))

# Unset environment variable 
unset LVM_SUPPRESS_FD_WARNINGS

echo "---- Ending MONGO flush with read lock and LVM snapshot ---- "
echo "     -> lock length: $date_lock_length seconds --" | tee -a $SQL_SNAP_LOG

#
## mount snapshot
echo "---- Mounting LVM snapshot ---- "
mount /dev/$MY_VG/$SNAP_NAME $SNAP_MOUNT
if [ $? -ne 0 ]; then
echo "Error: Mount error !" >&2
exit 1
else
echo "---- Mounted ---- "
fi

cd /

SOURCE_FOLDER="$SNAP_MOUNT/$MY_LV_DATADIR $SQL_SNAP_LOG $MYLVM_EXTRA_DATA"

#
## prepare a list of folders stripped from their leading / char
for folder in ${SOURCE_FOLDER}
do
STRIPPED_SOURCE_FOLDER="${folder:1} $STRIPPED_SOURCE_FOLDER"
done

#
## backup in tar.gz file
echo "---- Starting Tar archive of Mongo data + config file + log files ---- "
date_tar_start=`date "+%s"`
tar czCf / $BACKUP_FILE $STRIPPED_SOURCE_FOLDER
date_tar_end=`date "+%s"`
date_tar_length=$((date_tar_end-date_tar_start))
echo "---- Ending Tar archive ---- "
echo "     -> tar length: $date_tar_length seconds" 

#
## umount snapshot
cd ..
echo "---- Unmounting LVM snapshot ---- "
umount $SNAP_MOUNT
if [ $? -ne 0 ]; then
echo "Error: Unmount error !" >&2
exit 1
else
echo "---- Unmounted ---- "
fi

#
## delete snapshot -- don't ask for confirmation
echo "---- Removing LVM snapshot ---- "
$LVREMOVE -f /dev/$MY_VG/$SNAP_NAME
if [ $? -ne 0 ]; then
echo "Error: LVM remove error !" >&2
exit 1
else
echo "---- LVM snapshot removed ---- "
fi

# if we reach that point we have completed the backup with success !
logger "$DATE - `basename $0` | LVM Mongo Backup complete"